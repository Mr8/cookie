#!/bin/sh
/home/dholth/prog/py27/bin/tox -e py26,py27,pypy,py32,py33
