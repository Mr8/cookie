#!/bin/sh
# Vendorize pkg_resources and _markerlib from ../distribute/

cp ../pep425/pep425tags.py wheel
